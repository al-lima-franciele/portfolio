<?php

/* Custom widgets */
require_once tt_file_require(get_template_directory() . '/framework/widgets/social_links_widget.php');

?>